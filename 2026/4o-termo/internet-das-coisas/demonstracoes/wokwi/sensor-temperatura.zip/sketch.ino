#include <Bonezegei_DHT22.h>
#define LED 4

Bonezegei_DHT22 dht(18);

void setup() {
  Serial.begin(115200);
  pinMode(4, OUTPUT);
  dht.begin();
}

void loop() {
  if (dht.getData()) {                         // get All data from DHT22
    float tempDeg = dht.getTemperature();      // return temperature in celsius
    float tempFar = dht.getTemperature(true);  // return temperature in fahrenheit if true celsius of false
    int hum = dht.getHumidity();               // return humidity
    Serial.printf("Temperature: %0.1lf°C  %0.1lf°F Humidity:%d \n", tempDeg, tempFar, hum);

    if (tempDeg >= 25.0) digitalWrite(LED, HIGH);
    else digitalWrite(LED, LOW);
  }
  delay(2000);
}
