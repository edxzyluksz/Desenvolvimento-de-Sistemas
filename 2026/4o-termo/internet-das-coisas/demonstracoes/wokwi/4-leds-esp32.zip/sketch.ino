#define VREF 5.0 // Tensão de comunicação
#define ADC_BITS 1023.0 // Amostragem de conversão (10 bits)

// Leds
#define RED_LED 19
#define YELLOW_LED 5
#define GREEN_LED 18
#define BLUE_LED 17

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(BLUE_LED, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int sensorValue = analogRead(27);
  float voltage = sensorValue * (VREF / ADC_BITS);
  
  Serial.print(sensorValue);
  Serial.print(" --> ");
  Serial.print(voltage);
  Serial.println(" Volts\n");
  
  
  // Lógica do YELLOW LED
  if (voltage < (VREF / 5)) { // 1V
  	digitalWrite(YELLOW_LED, LOW);
  } else {
  	digitalWrite(YELLOW_LED, HIGH);
  }
  
  // Lógica do RED LED
  if (voltage < (VREF / 2)) { // 2,5V
  	digitalWrite(RED_LED, LOW);
  } else {
  	digitalWrite(RED_LED, HIGH);
  }
  
  // Lógica do GREEN_
  if (voltage < (VREF / 1.1)) { // 4,5V
  	digitalWrite(GREEN_LED, LOW);
  } else {
  	digitalWrite(GREEN_LED, HIGH);
  }
  
  
  // Lógica especial: Entre 3V e 3,5V
  if (voltage >= 3 && voltage <= 3.5) {
  	digitalWrite(BLUE_LED, HIGH);
  } else {
  	digitalWrite(BLUE_LED, LOW);
  }
  
  delay(500);
}
