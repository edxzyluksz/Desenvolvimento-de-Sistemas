#include <Bonezegei_DHT22.h>

// LEDS
#define VERMELHO 2
#define AMARELO 3
#define VERDE 4

// DHT22
#define DHT 5
Bonezegei_DHT22 dht(DHT);

// Sensor DHT c/ acionamento de LEDs
void setup() {
  Serial.begin(115200);
  pinMode(VERMELHO, OUTPUT);
  pinMode(AMARELO, OUTPUT);
  pinMode(VERDE, OUTPUT);

  dht.begin();
}

void loop() {
  if (dht.getData()) {
    float tempDeg = dht.getTemperature();
    Serial.println("Temperatura em Celsius: " + String(tempDeg));

    if (tempDeg < 25) {
      digitalWrite(VERMELHO, LOW);
      digitalWrite(AMARELO, LOW);
      digitalWrite(VERDE, HIGH); // !!!
    }

    if (tempDeg >= 25.1 && tempDeg <= 26.0) {
      digitalWrite(VERMELHO, LOW);
      digitalWrite(AMARELO, HIGH); // !!!
      digitalWrite(VERDE, LOW);
    }

    if (tempDeg > 26) {
      digitalWrite(VERMELHO, HIGH); // !!!
      digitalWrite(AMARELO, LOW);
      digitalWrite(VERDE, LOW);
    }
  }

  delay(500);
}
